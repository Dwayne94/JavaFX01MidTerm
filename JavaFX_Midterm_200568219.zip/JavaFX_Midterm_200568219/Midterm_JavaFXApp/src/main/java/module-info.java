module org.example.midterm_javafxapp {
    requires javafx.controls;
    requires javafx.fxml;


    opens org.example.midterm_javafxapp to javafx.fxml;
    exports org.example.midterm_javafxapp;
}