package org.example.midterm_javafxapp;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.sql.*;

public class Controller implements Initializable {

    @FXML
    private TextField patientIDTextField;

    @FXML
    private TextField symptomsTextField;

    @FXML
    private TextField diagnosisTextField;

    @FXML
    private TextField medicinesTextField;

    @FXML
    private CheckBox wardRequiredCheckBox;

    @FXML
    private Button addButton;

    @FXML
    private Button searchButton;

    @FXML
    private TableView<Diagnosis> diagnosisTableView;

    @FXML
    private TableColumn<Diagnosis, Integer> patientIDColumn;

    @FXML
    private TableColumn<Diagnosis, String> symptomsColumn;

    @FXML
    private TableColumn<Diagnosis, String> diagnosisColumn;

    @FXML
    private TableColumn<Diagnosis, String> medicinesColumn;

    @FXML
    private TableColumn<Diagnosis, Boolean> wardRequiredColumn;

    private ObservableList<Diagnosis> diagnosisData = FXCollections.observableArrayList();

    private Connection connection;
    private Statement statement;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        patientIDColumn.setCellValueFactory(new PropertyValueFactory<>("patientID"));
        symptomsColumn.setCellValueFactory(new PropertyValueFactory<>("symptoms"));
        diagnosisColumn.setCellValueFactory(new PropertyValueFactory<>("diagnosis"));
        medicinesColumn.setCellValueFactory(new PropertyValueFactory<>("medicines"));
        wardRequiredColumn.setCellValueFactory(new PropertyValueFactory<>("wardRequired"));

        connectToDatabase();

        diagnosisTableView.setItems(diagnosisData);
    }

    private void connectToDatabase() {
        try {
            // Replace with your database credentials
            String url = "jdbc:mysql://localhost:3306/db_prac";
            String user = "root";
            String password = "Blueoystercult94#";

            connection = DriverManager.getConnection(url, user, password);
            statement = connection.createStatement();
            System.out.println("Connected to database successfully!");

        } catch (SQLException e) {
            System.out.println("Error connecting to database: " + e.getMessage());
        }
    }

    @FXML
    void addDiagnosis() {
        try {
            int patientID = Integer.parseInt(patientIDTextField.getText());
            String symptoms = symptomsTextField.getText();
            String diagnosis = diagnosisTextField.getText();
            String medicines = medicinesTextField.getText();
            boolean wardRequired = wardRequiredCheckBox.isSelected();

            PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO tbl_diagnosis (patientID, symptoms, diagnosis, medicines, wardRequired) VALUES (?,?,?,?,?)");
            preparedStatement.setInt(1, patientID);
            preparedStatement.setString(2, symptoms);
            preparedStatement.setString(3, diagnosis);
            preparedStatement.setString(4, medicines);
            preparedStatement.setBoolean(5, wardRequired);

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Diagnosis added successfully!");
                clearInputFields();
            } else {
                System.out.println("Error adding diagnosis.");
            }
        } catch (SQLException | NumberFormatException e) {
            System.out.println("Error adding diagnosis: " + e.getMessage());
        }
    }

    @FXML
    void searchDiagnosis() {
        try {
            diagnosisData.clear();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM tbl_diagnosis");
            while (resultSet.next()) {
                int patientID = resultSet.getInt("patientID");
                String symptoms = resultSet.getString("symptoms");
                String diagnosis = resultSet.getString("diagnosis");
                String medicines = resultSet.getString("medicines");
                boolean wardRequired = resultSet.getBoolean("wardRequired");
                diagnosisData.add(new Diagnosis(patientID, symptoms, diagnosis, medicines, wardRequired));
            }
            diagnosisTableView.setItems(diagnosisData);
        } catch (SQLException e) {
            System.out.println("Error retrieving diagnosis data: " + e.getMessage());
        }
    }

    private void clearInputFields() {
        patientIDTextField.setText("");
        symptomsTextField.setText("");
        diagnosisTextField.setText("");
        medicinesTextField.setText("");
        wardRequiredCheckBox.setSelected(false);
    }
}