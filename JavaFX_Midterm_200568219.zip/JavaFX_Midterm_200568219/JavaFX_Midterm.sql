USE db_prac;

CREATE TABLE tbl_diagnosis
(
patientID INT PRIMARY KEY, 
symptoms VARCHAR(255), 
diagnosis VARCHAR(255),
medicines VARCHAR(255),
wardRequired BOOLEAN
);

SELECT * FROM tbl_diagnosis;